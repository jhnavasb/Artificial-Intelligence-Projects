To execute the file, please follow the next steps:

1- Open a terminal
2- cd to the current "Paint.py" location
3- Copy and paste the following line in your terminal "python ./Paint.py"
4- Enjoy!

Our team work is formed by
* Andrés Mejía
* Jhonatan Navas

(We made several drawings, and we couldn't choose between them, so, enjoy our little gallery) 


